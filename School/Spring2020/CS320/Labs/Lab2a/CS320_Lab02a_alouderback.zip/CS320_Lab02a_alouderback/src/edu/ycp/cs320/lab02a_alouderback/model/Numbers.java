package edu.ycp.cs320.lab02a_alouderback.model;

public class Numbers {
	private double first, second, third, result;
	
	public Numbers() {}
	
	public void setFirst(Double first) {
		this.first = first;
	}
	public double getFirst() {
		return first;
	}
	public void setSecond(Double second) {
		this.second = second;
	}
	public double getSecond() {
		return second;
	}
	public void setThird(Double third) {
		this.third = third;
	}
	public double getThird() {
		return third;
	}
	public void setResult(Double result) {
		this.result = result;
	}
	public double getResult() {
		return result;
	}
}
