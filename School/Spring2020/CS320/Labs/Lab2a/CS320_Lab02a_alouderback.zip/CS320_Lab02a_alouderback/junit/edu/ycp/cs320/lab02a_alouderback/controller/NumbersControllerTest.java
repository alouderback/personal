package edu.ycp.cs320.lab02a_alouderback.controller;

import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import edu.ycp.cs320.lab02a_alouderback.model.Numbers;

public class NumbersControllerTest {
	private Numbers model;
	private NumbersController controller;
	
	@Before
	public void setUp() {
		model = new Numbers();
		controller = new NumbersController();
		
		model.setFirst(1.8);
		model.setSecond(3.9);
		model.setThird(4.1);
		
		controller.setModel(model);
	}
	
	@Test
	public void testAdd() {
		controller.add();
		assertTrue(model.getResult() == (1.8+3.9+4.1));
	}
	@Test
	public void testMultiply() {
		controller.multiply();
		assertTrue(model.getResult() == (1.8*3.9));
	}
}
