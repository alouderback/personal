package edu.ycp.cs320.lab02a_alouderback.model;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

public class NumbersTest {
	private Numbers model;
	private static final double DELTA = 1e-15;
	
	@Before
	public void setUp() {
		model = new Numbers();
	}
	
	@Test
	public void testSetFirst() {
		model.setFirst(1.0);
		assertEquals(1.0, model.getFirst(), DELTA);
	}
	@Test
	public void testSetSecond() {
		model.setSecond(18.0);
		assertEquals(18.0, model.getSecond(), DELTA);
	}
	@Test
	public void testSetThird() {
		model.setThird(24.0);
		assertEquals(24.0, model.getThird(), DELTA);
	}
	@Test
	public void testSetResult() {
		model.setResult(100.0);
		assertEquals(100.0, model.getResult(), DELTA);
	}
}
